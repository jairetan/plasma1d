#pragma once

#include <vector>

#include "parameters.h"
#include "to_string.h"
#include "out_writer.h"

void pot_diagnostic (std::vector <double> *, int iter);
