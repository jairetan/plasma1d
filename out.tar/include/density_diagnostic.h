#pragma once

#include <vector>

#include <string>
#include "parameters.h"
#include "to_string.h"
#include "out_writer.h"

void density_diagnostic (std::vector <double> *, const int);
