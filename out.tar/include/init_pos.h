//Initialize position and/or velocity
#include <time.h>
#include <stdlib.h>
#include "parameters.h"
#pragma once
int random_start ();
