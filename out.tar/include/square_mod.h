#include <complex>
#include <fftw3.h>
#include <math.h>

double square_mod (std::complex <double> value);
