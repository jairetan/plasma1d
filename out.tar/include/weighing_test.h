#include <gtest/gtest.h>
#include "weighing.h"
#include "ion.h"
