#include <gtest/gtest.h>
#include "density.h"
#include "ion.h"
