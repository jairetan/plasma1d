#pragma once

#include <time.h>
#include <stdlib.h>
#include <cmath>
#include "parameters.h"
#include "wrap_around.h"

double random_vel (double mass, double boltzmann_temp);
