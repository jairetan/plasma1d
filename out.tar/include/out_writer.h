#pragma once
#include <string>
#include <vector>
#include <stdio.h>

void out_writer (std::string, std::vector <double> *, std::vector <double> *);
