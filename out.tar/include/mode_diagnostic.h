#pragma once
#include <complex>
#include <string>
#include "parameters.h"
#include "to_string.h"
#include <fftw3.h>
#include <vector>
#include <cmath>
//void mode_diagnostic (std::vector <double> *, int);
double mode_diagnostic (std::vector <double> *, std::vector <double> *, int);

