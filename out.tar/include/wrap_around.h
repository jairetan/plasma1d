#pragma once
#include "parameters.h"

double wrap_around (double position, double max_pos);
