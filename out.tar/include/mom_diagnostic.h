//Record system momentum at each time

#pragma once

#include <vector>
#include <particle.h>
#include "out_writer.h"
void mom_diagnostic (std::vector <Particle *> *, double);
