#include "field.h"
#include <gtest/gtest.h>

TEST (field_test, field_test)
{
    std::vector <double> field_vector;
    std::vector <double> pot_vector;
    std::vector <double> density_vector (NUM_CELLS);

    //calc_field (&field_vector, &pot_vector, &density_vector);

}
